package com.coding.daikichi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaikichApplicationTests {

	@Test
	void contextLoads() {
	}

}
