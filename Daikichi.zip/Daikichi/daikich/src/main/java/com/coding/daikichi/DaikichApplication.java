package com.coding.daikichi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichApplication.class, args);
	}

}
