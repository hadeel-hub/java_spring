/**
 * 
 */
/**
 * @author user
 *
 */
module Daikichi {
}